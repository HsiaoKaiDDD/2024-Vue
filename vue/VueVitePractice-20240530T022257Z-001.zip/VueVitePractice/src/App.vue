<template>
  <div class="flex justify-center items-center min-h-[100dvh] px-5 py-2 text-white">
    <RouterView />
  </div>
</template>
