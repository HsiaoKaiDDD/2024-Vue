<script>
export default {
};
</script>

<template>
  <div class="flex flex-col gap-y-2">
    <h1 class="text-8xl font-bold">Hello Vite + Vue!</h1>
  </div>
</template>

<style scoped>

</style>
